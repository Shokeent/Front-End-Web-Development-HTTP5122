//LAB 3 - ARRAYS & LOOPS - PART 1
alert("Hello world")

//ARRAY OF FRUITS
var FRUITS = ["Apple", "Mango", "Banana", "Pineapple", "Peach"]
//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX

console.log(FRUITS[2]);
alert(ourTeam[0]);