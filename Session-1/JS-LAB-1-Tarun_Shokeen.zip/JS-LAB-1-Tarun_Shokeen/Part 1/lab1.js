// alert("Hello World");

var myName = "Tarun Shokeen"; // String
var myAge = 24; // Number
var daysInAYear = 365;
var daysILived = myAge * daysInAYear;

var text = " days old... more or less.";

// alert(daysILived);

alert(myName + " " + "is" + " " + daysILived + text);